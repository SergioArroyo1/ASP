﻿using System;

public class Program
{
    public static void Main(string[] args)
    {
        List<string> nombres = new List<string> { "Ana", "Luis", "Marta" };
        var nombre = nombres.ToList();
        var longitud = nombres.Select(n => n.Length);
        Console.WriteLine("Nombres: " + string.Join(", ", nombre) +
            " Longitudes: " + string.Join(", ", longitud));
    }
}
