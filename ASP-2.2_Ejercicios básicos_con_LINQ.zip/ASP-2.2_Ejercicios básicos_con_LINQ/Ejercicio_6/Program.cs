﻿using System;
using System.Linq;

public class Program
{
    public static void Main(string[] args)
    {
        List<int> lista = new List<int> { 1, 2, 2, 3, 3, 3, 4 };
        var n = from nu in lista where nu > 1 select nu;
        Console.WriteLine("Promedio: " + n.Average());
    }
}
