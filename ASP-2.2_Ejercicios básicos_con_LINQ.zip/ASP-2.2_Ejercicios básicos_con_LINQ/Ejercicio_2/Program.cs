﻿using System;

public class Program
{
    public static void Main(string[] args)
    {
        int[] numeros = { 5, 12, 8, 23, 4, 16, 19, 7, 10, 3 };

        var dobles = from n in numeros select n * 2;
        var ordenadosDesc = numeros.OrderByDescending(n => n);
        Console.WriteLine("Orden descendente: " + string.Join(", ", ordenadosDesc));

        foreach (var n in dobles)
        {
            Console.WriteLine(n);
        }
    }
}
