﻿using System;

public class Program
{
    public static void Main(string[] args)
    {
        int[] numeros = { 5, 12, 8, 23, 4, 16, 19, 7, 10, 3 };

        var mayoresDe10 = from n in numeros where n > 10 select n;
        
            foreach(var n in mayoresDe10)
        {
            Console.WriteLine(n);
        }

    }
}