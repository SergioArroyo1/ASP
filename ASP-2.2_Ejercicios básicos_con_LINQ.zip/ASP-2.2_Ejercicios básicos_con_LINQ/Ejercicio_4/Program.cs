﻿using System;

public class Program
{
    public static void Main(string[] args)
    {
        List<int> lista = new List<int> { 1, 2, 4, 4, 6, 8, 2, 10, 3 };
        // Where: filtrar números pares
        var pares = lista.Where(n => n % 2 == 0);
        var impares = lista.Where(n => n % 2 != 0);
        Console.WriteLine("Números pares: " + string.Join(", ", pares) + 
        " Números impares: " + string.Join(", ", impares));
    }
}

