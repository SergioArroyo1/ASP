﻿using System;

public class Program
{
    public static void Main(string[] args)
    {
        List<int> lista = new List<int> { 2, 4, 4, 6, 8, 2, 10 };
        var sinDuplicados = lista.Distinct();
        var suma = sinDuplicados.Sum();
        Console.WriteLine("Sin duplicados: " + string.Join(", ", sinDuplicados));
        // Sum: suma de todos los números
        Console.WriteLine("Suma: " + suma);

    }


}

