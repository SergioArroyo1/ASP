﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace EjercicioCafe
{
    public partial class FormPedido : Form
    {
        public FormPedido()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void btnConfirmar_Click(object sender, EventArgs e)
        {
            string mensaje = $"Pedido registrado: \n\n " +
                $"Cliente: {txtNombre.Text}\n" +
                $"Producto: {txtProducto.Text}\n" +
                $"Cantidad: {txtCantidad.Text} \n\n" +
                $"¡Gracias por su pedido!";
            MessageBox.Show(mensaje, "Pedido confirmado",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);

        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            txtNombre.Text = "";
            txtProducto.Text = "";
            txtCantidad.Text = "";
        }
    }
}
