﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

class Equipo
{
    public int Id { get; set; }
    public string? Nombre { get; set; }
}

class Competicion
{
    public int Id { get; set; }
    public string? Nombre { get; set; }
}

class Partido
{
    public int Id { get; set; }
    public int Equipo1Id { get; set; }
    public int Equipo2Id { get; set; }
    public int CompeticionId { get; set; }
    public string? Resultado { get; set; }
    public DateOnly Fecha { get; set; }
}

class Program
{
    static void Main()
    {
        List<string> datos = new List<string> {
            "Real Madrid;Barcelona;2-1;Liga;2025-10-12",
            "Atlético de Madrid;Sevilla;1-0;Liga;2025-10-13",
            "Barcelona;Valencia;3-2;Copa del Rey;2025-10-14",
            "Sevilla;Real Madrid;0-2;Liga;2025-10-15",
            "Valencia;Atlético de Madrid;1-1;Copa del Rey;2025-10-16",
            "Real Madrid;Atlético de Madrid;2-2;Liga;2025-10-17",
            "Barcelona;Sevilla;4-0;Liga;2025-10-18",
            "Valencia;Real Madrid;0-1;Copa del Rey;2025-10-19",
            "Atlético de Madrid;Barcelona;1-3;Liga;2025-10-20",
            "Sevilla;Valencia;2-2;Copa del Rey;2025-10-21"
        };

     
        var parsed =
            (from pair in datos.Select((value, index) => new { value, index })
             let f = pair.value.Split(';')
             select new
             {
                 Id = pair.index + 1,
                 Local = f[0],
                 Visitante = f[1],
                 Resultado = f[2],
                 Competicion = f[3],
                 Fecha = DateOnly.ParseExact(f[4], "yyyy-MM-dd", CultureInfo.InvariantCulture)
             }).ToList();

 
        var equipoNombres =
            (from p in parsed
             from nombre in new[] { p.Local, p.Visitante }
             group nombre by nombre into g
             select g.Key).ToList();

        var equipos =
            (from t in equipoNombres.Select((nombre, i) => new { nombre, i })
             select new Equipo { Id = t.i + 1, Nombre = t.nombre }).ToList();

   
        var competicionNombres =
            (from p in parsed
             group p.Competicion by p.Competicion into g
             select g.Key).ToList();

        var competiciones =
            (from t in competicionNombres.Select((nombre, i) => new { nombre, i })
             select new Competicion { Id = t.i + 1, Nombre = t.nombre }).ToList();

        var equipoLookup = equipos.ToDictionary(e => e.Nombre!, e => e.Id, StringComparer.Ordinal);
        var competicionLookup = competiciones.ToDictionary(c => c.Nombre!, c => c.Id, StringComparer.Ordinal);

        var partidos =
            (from p in parsed
             select new Partido
             {
                 Id = p.Id,
                 Equipo1Id = equipoLookup[p.Local],
                 Equipo2Id = equipoLookup[p.Visitante],
                 CompeticionId = competicionLookup[p.Competicion],
                 Resultado = p.Resultado,
                 Fecha = p.Fecha
             }).ToList();


        Console.WriteLine("Equipos:");
        foreach (var e in equipos)
            Console.WriteLine($"{e.Id}: {e.Nombre}");

        Console.WriteLine();
        Console.WriteLine("Competiciones:");
        foreach (var c in competiciones)
            Console.WriteLine($"{c.Id}: {c.Nombre}");

        Console.WriteLine();
        Console.WriteLine("Partidos:");
        foreach (var p in partidos)
            Console.WriteLine($"{p.Id}:  Equipo1={p.Equipo1Id},  Equipo2={p.Equipo2Id},  Competicion={p.CompeticionId},  Resultado={p.Resultado},  Fecha={p.Fecha:dd/MM/yyyy}");
    }
}
